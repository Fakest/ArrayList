package arraylists;

import java.util.Scanner;

public class Controller {
    public static void main(String arges[]){
        Courses courses = new Courses();
        Scanner in = new Scanner(System.in);
        System.out.println("Enter a students name and you will be told if they are in the class");
        String inp = in.nextLine();
        courses.searchArray(inp);
    }
}
