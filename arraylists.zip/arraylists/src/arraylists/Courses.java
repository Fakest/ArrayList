package arraylists;

import java.util.ArrayList;

public class Courses {

    ArrayList<String> students = new ArrayList<String>();
    public Courses() {
        String course = "BCS Applied Computing Science";
        students.add("Harry Beggs");
        students.forEach((temp) -> {
            System.out.println(temp);
        });
    }
    public void searchArray(String inp){
        boolean objFound;
        objFound = students.contains(inp);
        if(objFound == true){
            System.out.println("Student found");
        }else{
            System.out.println("Student not found");
        }
    }
}
